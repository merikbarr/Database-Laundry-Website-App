
## How to try out the code

The easiest way to read through this code, try it out and play with it is to follow these instructions:
- download the Spring Tool Suite (http://spring.io/tools/sts/all) 
- open this project inside the Spring Tool Suite
- find the class Application in left side Package Explorer
- right click on class Application > Run as .. > Spring Boot App
- check the console on the bottom for something like "Started Application in 9.06 seconds"
- go to browser and the application should be running under http://localhost:8080/developers

That's all. :)
