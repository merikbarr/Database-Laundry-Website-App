package com.example;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

    @Autowired
    DeveloperRepository developerRepository;

    @Autowired
    SkillRepository skillRepository;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

	@Override
	public void run(String... args) throws Exception {
		Skill Pakaian = new Skill("Pakaian", "Atasan");
		Skill BedCover = new Skill("BedCover", "BedCover Tebal");
		Skill Bantal = new Skill("Bantal", "Bantal panjang");
		Skill Gordyn = new Skill("Gordyn", "Gordyn Jendela");
		Skill Gaun = new Skill("Gaun", "Gaun Wanita");
		Skill Jas = new Skill("Jas", "Jas Pria");
		Skill Karpet = new Skill("Karpet", "Karpet bulu sedang");
		Skill Selimut = new Skill("Selimut", "Selimut Sedang");



		skillRepository.save(Pakaian);
		skillRepository.save(Karpet);
		skillRepository.save(BedCover);
		skillRepository.save(Bantal);
		skillRepository.save(Gordyn);
		skillRepository.save(Selimut);
		skillRepository.save(Jas);
		skillRepository.save(Gaun);


		List<Developer> developers = new LinkedList<Developer>();
		developers.add(new Developer("Riandi", "Subagja", "rian.Sub@hotmail.com", "081286", "Sukamaju 4",
				Arrays.asList(new Skill[] {Pakaian, Karpet})));
		developers.add(new Developer("Markus", "Johnson", "mjohnson@example.com", "081286", "Sukamaju 4",
				Arrays.asList(new Skill[] {BedCover, Bantal})));
		developers.add(new Developer("Winda", "HM", "Winda.hidayah@example.com", "081286", "Sukamaju 4",
				Arrays.asList(new Skill[] {Bantal, Karpet})));
		developers.add(new Developer("Bertus", "Miller", "b.miller@yahoo.com", "081286", "Sukamaju 4",
				Arrays.asList(new Skill[] {BedCover, Bantal, Pakaian})));
		developers.add(new Developer("Julia", "Akbar", "julbar.student@harvard.com", "081286", "Sukamaju 4",
				Arrays.asList(new Skill[] {Gaun,Jas})));
		developerRepository.save(developers);
	}

}
